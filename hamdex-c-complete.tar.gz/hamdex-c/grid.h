/* grid.h — Maidenhead grid square <-> lat/lon, distance and bearing */
#ifndef HAMDEX_GRID_H
#define HAMDEX_GRID_H

#include <stdbool.h>

/* Converts a 4 or 6 character Maidenhead grid square into lat/lon (deg).
 * Returns true on success, false if the grid string is invalid. */
bool grid_to_latlon(const char *grid, double *out_lat, double *out_lon);

/* Great-circle distance in kilometers between two lat/lon points. */
double haversine_km(double lat1, double lon1, double lat2, double lon2);

/* Initial bearing in degrees (0-360) from point 1 to point 2. */
double initial_bearing(double lat1, double lon1, double lat2, double lon2);

/* 16-point compass label (e.g. "NNE") for a bearing in degrees. */
const char *bearing_label(double deg);

#endif
