#include "download.h"
#include <curl/curl.h>
#include <glib.h>
#include <string.h>

typedef struct {
    GByteArray *buf;
    download_progress_cb progress_cb;
    void *user_data;
    volatile int *cancel_flag;
    curl_off_t total;
} DlCtx;

static size_t write_cb(void *ptr, size_t size, size_t nmemb, void *userdata) {
    DlCtx *ctx = userdata;
    g_byte_array_append(ctx->buf, ptr, (guint)(size * nmemb));
    if (ctx->progress_cb) {
        char msg[128];
        if (ctx->total > 0) {
            int pct = (int)((double)ctx->buf->len / (double)ctx->total * 18.0); /* 0-18%, rest is import */
            g_snprintf(msg, sizeof(msg), "Downloading... %u/%lld MB",
                       ctx->buf->len / 1048576, (long long)(ctx->total / 1048576));
            ctx->progress_cb(msg, pct, ctx->user_data);
        } else {
            g_snprintf(msg, sizeof(msg), "Downloading... %u MB", ctx->buf->len / 1048576);
            ctx->progress_cb(msg, 0, ctx->user_data);
        }
    }
    return size * nmemb;
}

static int xferinfo_cb(void *clientp, curl_off_t dltotal, curl_off_t dlnow,
                        curl_off_t ultotal, curl_off_t ulnow) {
    (void)dltotal; (void)dlnow; (void)ultotal; (void)ulnow;
    DlCtx *ctx = clientp;
    if (ctx->cancel_flag && *ctx->cancel_flag) return 1; /* abort */
    return 0;
}

bool download_to_memory(const char *url,
                         unsigned char **out_data, size_t *out_size,
                         download_progress_cb progress_cb, void *user_data,
                         volatile int *cancel_flag,
                         char **err_msg) {
    *out_data = NULL;
    *out_size = 0;
    if (err_msg) *err_msg = NULL;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    CURL *curl = curl_easy_init();
    if (!curl) {
        if (err_msg) *err_msg = g_strdup("Could not initialize HTTP client.");
        return false;
    }

    DlCtx ctx = {0};
    ctx.buf = g_byte_array_new();
    ctx.progress_cb = progress_cb;
    ctx.user_data = user_data;
    ctx.cancel_flag = cancel_flag;

    if (progress_cb) progress_cb("Connecting to FCC...", 0, user_data);

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "HamDex/C-1.0");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 300L);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, xferinfo_cb);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &ctx);

    CURLcode res = curl_easy_perform(curl);

    long http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    bool ok = false;
    if (res == CURLE_ABORTED_BY_CALLBACK) {
        if (err_msg) *err_msg = NULL; /* cancelled, not an error */
    } else if (res != CURLE_OK) {
        if (err_msg) *err_msg = g_strdup_printf("Could not connect: %s", curl_easy_strerror(res));
    } else if (http_code >= 400) {
        if (err_msg) *err_msg = g_strdup_printf("Server returned HTTP %ld", http_code);
    } else {
        ok = true;
    }

    curl_easy_cleanup(curl);
    curl_global_cleanup();

    if (ok) {
        *out_size = ctx.buf->len;
        *out_data = g_byte_array_free(ctx.buf, FALSE);
    } else {
        g_byte_array_free(ctx.buf, TRUE);
    }
    return ok;
}
