/* grid.c — Maidenhead grid square <-> lat/lon, distance and bearing */
#include "grid.h"
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <stdio.h>

static bool is_valid_grid(const char *g, size_t len) {
    if (len != 4 && len != 6) return false;
    if (g[0] < 'A' || g[0] > 'R') return false;
    if (g[1] < 'A' || g[1] > 'R') return false;
    if (!isdigit((unsigned char)g[2]) || !isdigit((unsigned char)g[3])) return false;
    if (len == 6) {
        if (g[4] < 'A' || g[4] > 'X') return false;
        if (g[5] < 'A' || g[5] > 'X') return false;
    }
    return true;
}

bool grid_to_latlon(const char *grid, double *out_lat, double *out_lon) {
    if (!grid) return false;
    char g[8] = {0};
    size_t n = strlen(grid);
    if (n < 4 || n > 6) return false;
    for (size_t i = 0; i < n && i < 6; i++) {
        char c = grid[i];
        g[i] = (i < 2) ? (char)toupper((unsigned char)c) : (char)((i < 4) ? c : toupper((unsigned char)c));
    }
    /* trim to 4 or 6 */
    size_t len = (n >= 6) ? 6 : 4;
    if (!is_valid_grid(g, len)) return false;

    double lon = (g[0] - 'A') * 20.0 - 180.0;
    double lat = (g[1] - 'A') * 10.0 - 90.0;
    lon += (g[2] - '0') * 2.0;
    lat += (g[3] - '0') * 1.0;

    if (len == 6) {
        lon += (g[4] - 'A') * (5.0 / 60.0) + (2.5 / 60.0);
        lat += (g[5] - 'A') * (2.5 / 60.0) + (1.25 / 60.0);
    } else {
        lon += 1.0;
        lat += 0.5;
    }
    *out_lat = lat;
    *out_lon = lon;
    return true;
}

double haversine_km(double lat1, double lon1, double lat2, double lon2) {
    const double R = 6371.0;
    double dlat = (lat2 - lat1) * M_PI / 180.0;
    double dlon = (lon2 - lon1) * M_PI / 180.0;
    double a = sin(dlat / 2) * sin(dlat / 2) +
               cos(lat1 * M_PI / 180.0) * cos(lat2 * M_PI / 180.0) *
               sin(dlon / 2) * sin(dlon / 2);
    double c = a > 1.0 ? 1.0 : (a < 0.0 ? 0.0 : a);
    return R * 2.0 * atan2(sqrt(c), sqrt(1.0 - c));
}

double initial_bearing(double lat1, double lon1, double lat2, double lon2) {
    double dlon = (lon2 - lon1) * M_PI / 180.0;
    double la1 = lat1 * M_PI / 180.0, la2 = lat2 * M_PI / 180.0;
    double x = sin(dlon) * cos(la2);
    double y = cos(la1) * sin(la2) - sin(la1) * cos(la2) * cos(dlon);
    double brg = atan2(x, y) * 180.0 / M_PI;
    brg = fmod(brg + 360.0, 360.0);
    return brg;
}

const char *bearing_label(double deg) {
    static const char *dirs[16] = {
        "N","NNE","NE","ENE","E","ESE","SE","SSE",
        "S","SSW","SW","WSW","W","WNW","NW","NNW"
    };
    int idx = (int)((deg / 22.5) + 0.5) % 16;
    if (idx < 0) idx += 16;
    return dirs[idx];
}
